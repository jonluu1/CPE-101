#
# This is a header block example for lab 1.
#
# You will need to supply the following information.
#
# Name: Jonathan Luu
# Instructor: Hollister
# Section: CSC 101_09_2183
#

print ("Hello, World.")
